import java.util.*
import java.io.File

//definir el elemtno de tip HUffman
abstract class Huffman(var f: Int): Comparable<Huffman>{
    override fun compareTo(other: Huffman) = f - other.f
}

//un elemento final que no tiene hijos
class Hoja(freq: Int, var valor: Char): Huffman(freq)

//un elemento nodo que tiene hijos
class Nodo(var izq: Huffman, var der: Huffman): Huffman(izq.f + der.f)


fun CrearArbol(ArrayFreq: IntArray): PriorityQueue<Huffman> {
    //crear una cola para que alamcene el arbol
    var arbol = PriorityQueue<Huffman>()

    //el array de frecuencias llama a todos sus indices para insertarlos como hojas en el arbol
    for ((index, i) in ArrayFreq.withIndex()){
        if(i>0) arbol.offer(Hoja(i,index.toChar()))
    }
    /* ese for es exactamente lo mismo que...
    Array.ForEachIndexed { index,i ->
        if(i > 0) arbol.offer(Hoja(i,index.toChar()))
    }
    */

    //devuelve el arbol
    return arbol
}

fun comprimir(arbol: PriorityQueue<Huffman>): Huffman{

    //queremos que solo quede un elemento en la cola
    while (arbol.size > 1) {
        //decolar dos elementos de la cola
        var rama1 = arbol.poll()
        var rama2 = arbol.poll()

        //los elementos decolados vuelven a arbol pero como un solo elemento(nodo)
        arbol.offer(Nodo(rama1,rama2))
    }

    //devuelve la cola con un solo elemento que es el nodo que contiene el resto de elementos
    return arbol.peek()
}

fun Mostrar(arbol: Huffman, temp: StringBuffer){
    when(arbol) {
        //si el elemento es una hoja, imprime valor, frecuencia y el codigo huffman
        is Hoja -> println("${arbol.valor}\t\t\t${arbol.f}\t\t\t$temp")
        //si es nodo, buscara dentro del arbol de izquierda a derecha, hasta encontrar todas las hojas
        is Nodo -> {
            //izquierda
            temp.append('0')
            Mostrar(arbol.izq,temp)
            temp.deleteCharAt(temp.lastIndex)
            //derecha
            temp.append('1')
            Mostrar(arbol.der,temp)
            temp.deleteCharAt(temp.lastIndex)
        }
    }
}

fun main() {
    //archivo toma la cadena de un archivo txt y lo imprime
    val archivo = File("prueba2.txt").readText()
    println("texto a analizar: $archivo")

    //settear el array de frecuencias con un tamaño igual al maximo indice del archivo (+1 para controlar el error "OutOfBounds")
    val maximo = archivo.max()!!.toInt() + 1
    var frecuencias = IntArray(maximo)

    //poder alamcenar en el array por cada caracter del string (+= 1 indica la frecuencia de salto o algo asi)
    archivo.forEach { frecuencias[it.toInt()] +=1}

    //imprimir para comprobar el array de frecuencias
    /*
    frecuencias.forEachIndexed { index, i -> print("$i ")}
    println()
    */
    //arbol tomara el arbol que devuelva la funcion crearArbol (solo sera un nodo con todas las hojas comprimidas)
    val arbol = CrearArbol(frecuencias)
    val compresion = comprimir(arbol)

    //imprimir en pantalla
    println("valor\t\tfrecuencia\tHuffman")
    Mostrar(compresion,StringBuffer())
}